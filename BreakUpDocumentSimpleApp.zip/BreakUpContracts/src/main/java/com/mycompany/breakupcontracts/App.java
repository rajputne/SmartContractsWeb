package com.mycompany.breakupcontracts;

import com.me.SmartContracts.Utils.DocumentReader;

/**
 * Hello world!
 *
 */
public class App {

    public static void main(String[] args) {
        String filepath = "C:\fakepath";
        String fileName = "Contract1.pdf";
        /*
         * TODO output your page here. You may use following sample code.
         */
        String docText = DocumentReader.readDocument(filepath, fileName);
        System.out.println("Hello World!");

        BufferedReader br = new BufferedReader(new FileReader("file.txt"));
        try {
            StringBuilder sb = new StringBuilder();
            String line = br.readLine();

            while (line != null) {
                sb.append(line);
                sb.append(System.lineSeparator());
                line = br.readLine();
            }
            String everything = sb.toString();
        } finally {
            br.close();
        }
    }
}
