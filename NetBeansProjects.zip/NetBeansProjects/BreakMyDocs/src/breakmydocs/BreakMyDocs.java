/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package breakmydocs;

import java.io.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.apache.tika.Tika;
import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.pdf.PDFParser;
import org.apache.tika.sax.BodyContentHandler;
import org.xml.sax.SAXException;

/**
 *
 * @author rajput.ne
 */
public class BreakMyDocs {

    /**
     * @param args the command line arguments
     */
    public static String readFile(String filename) {
        String content = null;
        File file = new File(filename); //for ex foo.txt
        FileReader reader = null;
        try {
            reader = new FileReader(file);
            char[] chars = new char[(int) file.length()];
            reader.read(chars);
            content = new String(chars);
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (IOException ex) {
                    Logger.getLogger(BreakMyDocs.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        System.out.println(content);
        return content;
    }

    public static void main(String[] args) {
        // TODO code application logic here
        String docText = "";

        Tika tika = new Tika();
        String fileEntry = "C:\\fakepath\\Contract1.pdf";
        String filetype = tika.detect(fileEntry);
        System.out.println("FileType " + filetype);
        BodyContentHandler handler = new BodyContentHandler(-1);

        Metadata metadata = new Metadata();

        FileInputStream inputstream = null;
        try {
            inputstream = new FileInputStream(fileEntry);
        } catch (FileNotFoundException ex) {
            System.err.print("Something worng" + ex.getMessage());
        }
        ParseContext pcontext = new ParseContext();

        //parsing the document using PDF parser
        PDFParser pdfparser = new PDFParser();
        try {
            try {
                pdfparser.parse(inputstream, handler, metadata, pcontext);
            } catch (SAXException ex) {
                Logger.getLogger(BreakMyDocs.class.getName()).log(Level.SEVERE, null, ex);
            }
        } catch (IOException ex) {
            System.err.print("Something worng" + ex.getMessage());

        } catch (TikaException ex) {
            System.err.print("Something worng" + ex.getMessage());
        }

        //getting the content of the document
        docText = handler.toString().replaceAll("(/[^\\da-zA-Z.]/)", "");

        docText = readFile("Sentence.txt");
        System.out.println(docText);

    }
}
